package com.qa.orangehrm.pages;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import static org.testng.Assert.assertEquals;
import com.qa.orangehrm.base.TestBase;
import com.qa.orangehrm.util.TestUtil;

public class HomePage extends TestBase{
	
	//Basic Object Repository
	
	
	@FindBy(id="menu_recruitment_viewRecruitmentModule")
	WebElement menu_recruitment_viewRecruitmentModule;
	
	@FindBy(id="menu_recruitment_viewCandidates")
	WebElement menu_recruitment_viewCandidates;
	
	@FindBy(id="btnAdd")
	WebElement btnAdd;
	
	@FindBy(id="addCandidate_firstName")
	WebElement addCandidate_firstName;
	
	@FindBy(id="addCandidate_lastName")
	WebElement addCandidate_lastName;
	
	@FindBy(id="addCandidate_email")
	WebElement addCandidate_email;
	
	@FindBy(id="btnSave")
	WebElement btnSave;
	
	@FindBy(id="btnBack")
	WebElement btnBack;
	
	@FindBy(id="btnSrch")
	WebElement btnSrch;
	
	@FindBy(id="candidateSearch_candidateName")
	WebElement candidateSearch_candidateName;
	
	@FindBy(linkText ="SHRUTI PANDEY")
	WebElement validateSearch;
	
	public HomePage() {
		PageFactory.initElements(driver, this);
	}
	
	public void assertHomePageTitle() {
		assertEquals(driver.getTitle(),"OrangeHRM");
	}

	
	public void addCandidateAndValidate() {
		
		Actions act = new Actions(driver);
		act.moveToElement(menu_recruitment_viewRecruitmentModule).build().perform();
		act.moveToElement(menu_recruitment_viewCandidates).click().build().perform();
		act.moveToElement(btnAdd).click().build().perform();
		addCandidate_firstName.sendKeys("SHRUTI");
		addCandidate_lastName.sendKeys("PANDEY");
		addCandidate_email.sendKeys("shruti@gmail.com");
		btnSave.click();
		btnBack.click();
		candidateSearch_candidateName.sendKeys("SHRUTI PANDEY");
		btnSrch.click();
		validateSearch.click();
		System.out.println("Added Candidate Successfully");
		
	}
	

	
	
}
