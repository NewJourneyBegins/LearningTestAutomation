package com.qa.orangehrm.pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.orangehrm.base.TestBase;

public class LogInPage extends TestBase {

	// LoginPage Object Repository
	@FindBy(id="txtUsername")
	WebElement txtUsername;
	
	@FindBy(id="txtPassword")
	WebElement txtPassword;
	
	@FindBy(id="btnLogin")
	WebElement btnLogin;


	// Initializing the Page Objects
	public LogInPage() {

		PageFactory.initElements(driver, this);
	}

	public void assertLogInPageTitle() {
		assertEquals(driver.getTitle(), "OrangeHRM");
	}

	public  HomePage logIn() {
		txtUsername.sendKeys(prop.getProperty("username"));
		txtPassword.sendKeys(prop.getProperty("password"));
		btnLogin.click();
		
		return new HomePage();
	}
	
	public void logInCheck(String Username, String Password) {
		txtUsername.sendKeys(Username);
		txtPassword.sendKeys(Password);
		btnLogin.click();	
	}


}
