package com.qa.orangehrm.pages;

public class PayBillsPage {

	
	//No need to add anything for this scenario
}
