package com.qa.orangehrm.testcases;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.orangehrm.base.TestBase;
import com.qa.orangehrm.pages.HomePage;
import com.qa.orangehrm.pages.LogInPage;

public class LogInPageTestcases extends TestBase {

	HomePage homePage;
	LogInPage logInPage;

	public LogInPageTestcases() {
		super();
	}

	@BeforeMethod(alwaysRun = true)
	public void setUp() {
		initialization();
		homePage = new HomePage();
		logInPage = new LogInPage();
	}

	@AfterMethod(alwaysRun = true)
	public void cleanUp() {
		// close driver
		driver.close();
		driver.quit();
	}

	// positive
	@Test(priority = 1, groups = { "Smoke" })
	public void validate_LogIn_Functionality_Valid_Credentials() {
		//Validate Title
		 logInPage.assertLogInPageTitle();
		 
		 //perform login
		 homePage = logInPage.logIn();
		 
	}

	
	

}
