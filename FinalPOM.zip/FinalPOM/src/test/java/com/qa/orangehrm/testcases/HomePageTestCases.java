package com.qa.orangehrm.testcases;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.orangehrm.base.TestBase;
import com.qa.orangehrm.pages.HomePage;
import com.qa.orangehrm.pages.LogInPage;
import com.qa.orangehrm.util.TestUtil;

public class HomePageTestCases extends TestBase {
	
	HomePage  homePage;
	LogInPage logInPage;
	TestUtil testUtil;
	
	public HomePageTestCases() {
		super();
	}
	
	@BeforeMethod(alwaysRun = true)
	public void setUp() {
		initialization();
		homePage = new HomePage();
		logInPage = new LogInPage();
		testUtil = new TestUtil();
	}
	
	@AfterMethod(alwaysRun = true)
	public void cleanUp() {
		
	
		//close driver
		driver.close();
		driver.quit();
	}
	
	
	
	@Test
	public void AddCandidateAndValidationTest() {
		//Validate Title
		 logInPage.assertLogInPageTitle();
		 
		 //perform login
		 homePage = logInPage.logIn();
		 
		 //validate homepage title
		 homePage.assertHomePageTitle();
		 
		 //add candidate and validate
		homePage.addCandidateAndValidate();
	}
	
	
	

	


}
